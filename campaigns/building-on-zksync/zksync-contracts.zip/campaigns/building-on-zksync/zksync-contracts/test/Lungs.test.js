const { testLungs } = require("./testsuites/TestLungs.js");

describe("Lungs (Part 3)", function() {
  testLungs("Public Test 1", "Sound");
});
