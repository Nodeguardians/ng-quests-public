const { testStack } = require("./testsuites/TestStack.js");

describe("Stack (Part 2)", function () {
  testStack(`Public Test 1`);
});
