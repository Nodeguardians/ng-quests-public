const { testMemory } = require("./testsuites/TestMemory.js");

describe("Memory (Part 3)", function () {
  testMemory(`Public Test 1`);
});
